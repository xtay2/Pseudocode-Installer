# Pseudocode-stdlib
The standard-library for Pseudocode. Should sit in "C:\Program Files\Pseudocode\lib" when downloaded.
