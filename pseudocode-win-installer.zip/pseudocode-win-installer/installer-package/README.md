## Disclaimer!

 - All user-defined libraries should be stored in "%ProgramFiles%/Pseudocode/lib/usrlib/...".
 - Only click on files that start with a capital letter.
 - If you alter or remove any files from any subdirectory of "%ProgramFiles%/Pseudocode/...", the interpreter may not work anymore.
 - For help, visit the website: https://pseudocode.site or type "pseudocode help" into your shell.
